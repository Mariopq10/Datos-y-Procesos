package psp.serv.tickets.mpq;




public class Main {

	public static void main(String[] args) {

		Server servidor = new Server(2024,10);
		servidor.iniciarServidor();

	}
}
